import { useContext, useEffect } from 'react';

import {TempContext} from './TempContext'

  
export const Logout = () => {
  // log user out. it's just an inmemory value in context api
  const { isAuth, toggleAuth } = useContext(TempContext)
 
  return <div className='logout'  >
    <button className='logout-btn' onClick={() => {
       toggleAuth()
    }}> 
        LogOut
    </button>
  </div>;
};
